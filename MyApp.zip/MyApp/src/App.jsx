// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { EmployeeProvider } from './context/EmployeeContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import AddEmployee from './components/AddEmployee';
import EditEmployee from './components/EditEmployee';

const App = () => {
  return (
    <EmployeeProvider>
      <Router>
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/add-employee" component={AddEmployee} />
          <Route path="/edit-employee/:id" component={EditEmployee} />
        </Switch>
      </Router>
    </EmployeeProvider>
  );
};

export default App;
