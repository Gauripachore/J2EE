// src/components/EditEmployee.js
import React, { useContext, useState, useEffect } from 'react';
import { Link, useHistory, useParams } from 'react-router-dom';
import { EmployeeContext } from '../context/EmployeeContext';

const EditEmployee = () => {
  const { employees, editEmployee } = useContext(EmployeeContext);
  const history = useHistory();
  const { id } = useParams();

  const [employee, setEmployee] = useState({
    id: '',
    fullName: '',
    email: '',
    mobile: '',
  });

  useEffect(() => {
    // Find the employee with the specified ID
    const selectedEmployee = employees.find((emp) => emp.id === id);

    if (selectedEmployee) {
      setEmployee(selectedEmployee);
    }
  }, [employees, id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEmployee({ ...employee, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You may want to add validation here before editing the employee
    editEmployee(id, employee);
    history.push('/dashboard');
  };

  return (
    <div>
      <h2>Edit Employee</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Employee ID:
          <input
            type="text"
            name="id"
            value={employee.id}
            onChange={handleInputChange}
            readOnly
          />
        </label>
        <label>
          Full Name:
          <input
            type="text"
            name="fullName"
            value={employee.fullName}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            name="email"
            value={employee.email}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Mobile:
          <input
            type="tel"
            name="mobile"
            value={employee.mobile}
            onChange={handleInputChange}
          />
        </label>
        <button type="submit">Save Changes</button>
      </form>
      <Link to="/dashboard">
        <button>Back to Dashboard</button>
      </Link>
    </div>
  );
};

export default EditEmployee;
