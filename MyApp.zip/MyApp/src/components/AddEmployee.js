// src/components/AddEmployee.js
import React, { useContext, useState } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { EmployeeContext } from '../context/EmployeeContext';

const AddEmployee = () => {
  const { addEmployee } = useContext(EmployeeContext);
  const history = useHistory();

  const [employee, setEmployee] = useState({
    id: '',
    fullName: '',
    email: '',
    mobile: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEmployee({ ...employee, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You may want to add validation here before adding the employee
    addEmployee(employee);
    history.push('/dashboard');
  };

  return (
    <div>
      <h2>Add Employee</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Employee ID:
          <input
            type="text"
            name="id"
            value={employee.id}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Full Name:
          <input
            type="text"
            name="fullName"
            value={employee.fullName}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            name="email"
            value={employee.email}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Mobile:
          <input
            type="tel"
            name="mobile"
            value={employee.mobile}
            onChange={handleInputChange}
          />
        </label>
        <button type="submit">Add Employee</button>
      </form>
      <Link to="/dashboard">
        <button>Back to Dashboard</button>
      </Link>
    </div>
  );
};

export default AddEmployee;
