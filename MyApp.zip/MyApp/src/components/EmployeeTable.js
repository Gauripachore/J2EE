// src/components/EmployeeTable.js
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { EmployeeContext } from '../context/EmployeeContext';

const EmployeeTable = () => {
  const { employees, deleteEmployee } = useContext(EmployeeContext);

  return (
    <div>
      <h3>Employee List</h3>
      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.fullName}</td>
              <td>{employee.email}</td>
              <td>{employee.mobile}</td>
              <td>
                <Link to={`/edit-employee/${employee.id}`}>
                  <button>Edit</button>
                </Link>
                <button onClick={() => deleteEmployee(employee.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeTable;
