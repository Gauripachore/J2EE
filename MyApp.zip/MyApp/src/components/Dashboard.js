// src/components/Dashboard.js
import React from 'react';
import { Link } from 'react-router-dom';
import EmployeeTable from './EmployeeTable';

const Dashboard = () => {
  return (
    <div>
      <h2>Dashboard</h2>
      <Link to="/add-employee">
        <button>Add Employee</button>
      </Link>
      <EmployeeTable />
    </div>
  );
};

export default Dashboard;
